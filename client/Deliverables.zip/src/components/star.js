import {useEffect,useState} from 'react';
import '../css/star.css';

export default function Star(props)
{

    const [temp1,setTemp1]=useState([]);
    const [temp2,setTemp2]=useState([]);

    useEffect(()=>{
      let t1=[],t2=[]
      for(let i=0;i<props.rating;i++)t1.push(i);
      for(let i=0;i<5-props.rating;i++)t2.push(i);
      setTemp1(t1); setTemp2(t2);
    },[])

    return <div>
             <p>
               <label class='label label-primary'>Average Rating</label>&nbsp;&nbsp;{props.average_rating}  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                {
                  temp1.map((r)=>{return <span class="fa fa-star checked"></span>  })
                }
                {
                  temp2.map((r)=>{return <span class="fa fa-star"></span>    })
                }
            </p>
          </div>
}
