import React,{useState,useEffect} from 'react';
import {connect} from 'react-redux';
import {Link} from 'react-router-dom';

import Showbook from './showbook';
import navbar from './navbar';
import '../css/navbar.css';

const Cart=(props)=>{
   let s=0;
   const [total,setTotal]=useState(0);
   const [search,setSearch]=useState('');
   const [flag,setFlag]=useState(0);
   const [arr,setArr]=useState(props.cart);
   useEffect(()=>{
       if(props.cart.length==0 && !flag){ setFlag(1); props.loadCart(); }
       props.cart.map(c=>{s+=c.price*c.count; setTotal(s); });

       if(search=='')setArr(props.cart);
       else setArr(props.cart.filter(c=>c.title.toLowerCase().includes(search.trim().toLowerCase()) || c.authors.toLowerCase().includes(search.trim().toLowerCase()) ));

   },[props.cart])

  return <div>
          <div class="topnav"  id="myTopnav">
              <Link to="/">Home</Link>
              <Link  class="active" to="/cart">Cart</Link>
              <Link  to="/checkout">Checkout</Link>

                <a  href="javascript:void(0);" class="icon" onClick={navbar}>
                  <i class="fa fa-bars"></i>
                </a>
          </div>
          <br></br>
          <Link to='/checkout'  style={{float:'right',marginRight:'10px'}}><button class='btn btn-danger'>Checkout</button></Link>
          <p class='btn btn-primary' style={{marginLeft:'10px'}}>Total Amount:</p><p class='btn btn-success'>Rs.&nbsp; {total}</p>
          <br></br><br></br>
          <input type="text" placeholder="Search Cart" name="search" style={{float:'left',padding:'8px',fontSize:'17px',marginLeft:'10px',marginTop:'5px'}} size='50' value={search} onChange={(evt)=>setSearch(evt.target.value)}  />
          <br></br>  <br></br>  <br></br>

          {arr.sort(myFunc).map(c=><Showbook {...c} inccartproduct={props.inccartproduct} deccartproduct={props.deccartproduct}   removecartproduct={props.removecartproduct}/>)}
        </div>
}

function myFunc(a,b)
{
  return (a.bookID<b.bookID)?-1:(a.bookID>b.bookID)?1:0;
}

const mapStateToProps=(state)=>{
  return {cart:state.cartReducer}
}

const mapDispatchToProps=(dispatch)=>{
  return {
    loadCart:()=>{
        dispatch({type:'load_cart'});
    },

    inccartproduct:(bookID,title,authors,average_rating,isbn,language_code,ratings_count,price,count)=>{
            dispatch({type:'inc_cart_book',payload:{bookID,title,authors,average_rating,isbn,language_code,ratings_count,price,count}})
            dispatch({type:'inc_book',payload:bookID})

    },

    deccartproduct:(bookID,count)=>{
            if(count<=1)return;
            dispatch({type:'dec_cart_book',payload:{bookID,count}})
            dispatch({type:'dec_book',payload:bookID})

    },

    removecartproduct:(bookID)=>{
              dispatch({type:'remove_cart_book',payload:{bookID}})
              dispatch({type:'remove_book',payload:bookID})

    }
  }
}

export default connect(mapStateToProps,mapDispatchToProps)(Cart);
