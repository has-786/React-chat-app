import React from 'react';
import Star from './star';

export default function Showbook(props){

  return <div class='col-lg-4' style={{padding:'10px',marginBottom:'20px'}}>
             <div style={{border:'2px solid #003a9b',borderRadius:'10px',padding:'10px'}}>
                <div><label class='label label-primary'>Book ID</label> &nbsp;&nbsp; <b>{props.bookID}</b></div>              <br></br>
                <div><p class='titleECS'><label class='label label-primary'>Title</label>&nbsp;&nbsp;{props.title}</p></div>          <br></br>
                <div><p class='titleECS'><label class='label label-primary'>Authors</label>&nbsp;&nbsp;{props.authors}</p></div>          <br></br>
                <Star rating={Math.ceil(props.average_rating-0.5)} average_rating={props.average_rating}/> <br></br>
                <div><p><b class='label label-primary'>ISBN</b>&nbsp;&nbsp;{props.isbn}</p></div>          <br></br>
                <div><p><b class='label label-primary'>Language Code</b>&nbsp;&nbsp;{props.language_code}</p></div>          <br></br>
                <div><p><b class='label label-primary'>Rating Count</b>&nbsp;&nbsp;{props.ratings_count}</p></div>          <br></br>
                <div><p><b class='label label-primary'>Price</b>&nbsp;&nbsp;<b>Rs.&nbsp;{props.price}</b></p></div>         <br></br>

                <center><div>In cart: &nbsp; &nbsp;<button class='label label-success glyphicon glyphicon-plus' onClick={()=>props.inccartproduct(props.bookID,props.title,props.authors,props.average_rating
                  ,props.isbn,props.language_code,props.ratings_count,props.price,props.count)}> </button>&nbsp;&nbsp;<b>{props.count}</b> &nbsp; &nbsp;<button class='label label-danger glyphicon glyphicon-minus' onClick={()=>props.deccartproduct(props.bookID,props.count)}> </button></div></center>
                <br></br><br></br>
                <center><div><button class='btn btn-sm btn-danger' onClick={()=>props.removecartproduct(props.bookID)}>Remove From Cart</button></div></center>
              </div>
         </div>

}
