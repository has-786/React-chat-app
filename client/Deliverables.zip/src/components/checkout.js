import {useState,useEffect} from 'react';
import {connect} from 'react-redux';
import {Link} from 'react-router-dom';

import navbar from './navbar';
import '../css/navbar.css';

function Checkout(props){

let s=0;
const [total,setTotal]=useState(0);
const [flag,setFlag]=useState(0);
useEffect(()=>{
    if(props.cart.length==0 && !flag){ setFlag(1); props.loadCart(); }
    props.cart.map(c=>{s+=c.price*c.count; setTotal(s); });
})



return  <div >
          <div class="topnav"  id="myTopnav">
              <Link  to="/">Home</Link>
              <Link  to="/cart">Cart</Link>
              <Link  class="active" to="/checkout">Checkout</Link>

                <a  href="javascript:void(0);" class="icon" onClick={navbar}>
                  <i class="fa fa-bars"></i>
                </a>
          </div>

          <center>
             <div class='col-lg-4'></div>
             <div class='col-lg-4' style={{marginTop:'10%',padding:'0px',border:'2px solid purple',borderRadius:'10px'}}>
                        <br></br><br></br>
                        <p><label class='btn btn-sm btn-success'>Amount</label>&nbsp;&nbsp;&nbsp;&nbsp;Rs.&nbsp; <b>{total}</b></p>
                        <br></br><br></br>
                        <button class='btn btn-warning'  >Cash On Delivery</button>
                        <br></br><br></br>
                        <button  class='btn btn-danger'>Pay Online</button>
                        <br></br><br></br>
              </div>
              <div class='col-lg-4'></div>
            </center>
          </div>
  }

  const mapStateToProps=(state)=>{
    return {cart:state.cartReducer}
  }
  const mapDispatchToProps=(dispatch)=>{
    return {
      loadCart:()=>{
          dispatch({type:'load_cart'});
      }}
  }

  export default connect(mapStateToProps,mapDispatchToProps)(Checkout);
