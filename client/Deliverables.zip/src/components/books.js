import React,{useState,useEffect} from 'react';
import {connect} from 'react-redux';
import {Link} from 'react-router-dom';
import Showbook from './showbook';
import navbar from './navbar';
import '../css/navbar.css';


 const Books=(props)=>{
  // const [arr,setArr]=useState(props.book);
  const [search,setSearch]=useState('');
  const [flag,setFlag]=useState(0);
  const [arr,setArr]=useState(props.book);

   useEffect(()=>{
     if(props.book.length==0 && !flag)
     {
        setFlag(1);
        props.loadBooks();
        props.loadCart();
     }

     props.book.map(p=>{
      let obj=props.cart.find(c=>c.bookID==p.bookID);
       if(obj)p.count=obj.count;
       else p.count=0;
     });

     if(search=='')setArr(props.book);
     else setArr(props.book.filter(c=>c.title.toLowerCase().includes(search.trim().toLowerCase()) || c.authors.toLowerCase().includes(search.trim().toLowerCase()) ));

   },[props.book,props.cart,search]);

  return <div>
          <div class="topnav"  id="myTopnav">
              <Link class="active" to="/">Home</Link>
              <Link  to="/cart">Cart</Link>
              <Link  to="/checkout">Checkout</Link>

                <a  href="javascript:void(0);" class="icon" onClick={navbar}>
                  <i class="fa fa-bars"></i>
                </a>
          </div>
          <input type="text" placeholder="Search Books" name="search" style={{float:'left',padding:'8px',fontSize:'17px',marginLeft:'10px',marginTop:'5px'}} size='50' value={search} onChange={(evt)=>setSearch(evt.target.value)}  />
            <br/><br/><br/>
          {arr.map(p=><Showbook {...p} inccartproduct={props.inccartproduct} deccartproduct={props.deccartproduct} removecartproduct={props.removecartproduct}/>)}
        </div>
}

const mapStateToProps=(state)=>{
  return {book:state.bookReducer,cart:state.cartReducer}
}

const mapDispatchToProps=(dispatch)=>{
  return {
    loadBooks:()=>{
     const books=localStorage.getItem('book');
      if(books)dispatch({type:'load_books',payload:{books:JSON.parse(books)}});
      else{
              fetch("https://s3-ap-southeast-1.amazonaws.com/he-public-data/books8f8fe52.json")
              .then(response=>{ return response.json()})
              .then((body)=>{

                         dispatch({type:'load_books',payload:{books:body.slice(0,100)}});
                         localStorage.setItem('book',JSON.stringify(body.slice(0,100)));
                 })
                .catch(err=>alert(JSON.stringify(err)));
          }
      },

      loadCart:()=>{
          dispatch({type:'load_cart'});
      },

      inccartproduct:(bookID,title,authors,average_rating,isbn,language_code,ratings_count,price,count)=>{
            dispatch({type:'inc_cart_book',payload:{bookID,title,authors,average_rating,isbn,language_code,ratings_count,price,count}})
            dispatch({type:'inc_book',payload:bookID})
      },

      deccartproduct:(bookID,count)=>{
        if(count<=1)return;
        dispatch({type:'dec_cart_book',payload:{bookID,count}})
        dispatch({type:'dec_book',payload:bookID})
      },

      removecartproduct:(bookID)=>{
          dispatch({type:'remove_cart_book',payload:{bookID}})
          dispatch({type:'remove_book',payload:bookID})
        }
  }
}

export default connect(mapStateToProps,mapDispatchToProps)(Books);
