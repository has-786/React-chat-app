import React from 'react';
import ReactDom from 'react-dom';
import Books from './components/books';
import Cart from './components/cart';
import Checkout from './components/checkout';

import store from './store/configStore';
import {Provider} from 'react-redux';

import {BrowserRouter,Switch,Route,Link} from 'react-router-dom';



ReactDom.render(
  <Provider store={store}>
<BrowserRouter>
  <Switch>
    <Route exact path='/' component={Books} />
    <Route path='/cart' component={Cart} />
    <Route path='/checkout' component={Checkout} />

  </Switch>
</BrowserRouter>
</Provider>
,
document.getElementById('root'));
