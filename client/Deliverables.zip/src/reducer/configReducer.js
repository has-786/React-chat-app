import React from 'react';
import {combineReducers,createStore,applyMiddleware} from 'redux';

const bookReducer=(state=[],action)=>{
    let newState=[];
    switch(action.type)
    {
          case 'load_books':
            return action.payload.books;

          case 'inc_book':
            newState=[];
            state.map((s,ind)=>{newState.push(s); if(s.bookID==action.payload)newState[ind].count++; });
            return newState;

          case 'dec_book':
            newState=[];
            state.map((s,ind)=>{newState.push(s); if(s.bookID==action.payload && s.count>1)newState[ind].count--; });
            return newState;

          case 'remove_book':
            newState=[];
            state.map((s,ind)=>{newState.push(s); if(s.bookID==action.payload)newState[ind].count=0; });
            return newState;


          default:
            return state;
    }
}


const cartReducer=(state=[],action)=>{
    let newState=[];
    switch(action.type)
    {
      case 'load_cart':
        const cart=JSON.parse(localStorage.getItem('cart'));
        if(!cart)return state;
        return cart;

        case 'inc_cart_book':
          let obj=state.find(c=>c.bookID==action.payload.bookID);
          let obj1=action.payload;
          obj1.count++;
          newState=[];

          if(!obj){
            state.map((c,ind)=>{newState.push(c); })
            newState.push(obj1);
            localStorage.setItem('cart',JSON.stringify(newState));
            return newState;
          }

          state.map((c,ind)=>{newState.push(c); if(c.bookID==obj1.bookID)newState[ind].count++;})
          localStorage.setItem('cart',JSON.stringify(newState));
          return newState;


        case 'dec_cart_book':
          var x=state.find(cart=>cart.bookID==action.payload.bookID);
          if(x && x.count<=1)return state;

          newState=[];
          state.map((c,ind)=>{ newState.push(c); if(c.bookID==x.bookID)newState[ind].count--;})
          localStorage.setItem('cart',JSON.stringify(newState));
          return newState;

        case 'remove_cart_book':
            newState=state.filter(c=>c.bookID!=action.payload.bookID);
            localStorage.setItem('cart',JSON.stringify(newState));

            return newState;

        case 'clear_cart':
              newState=[];
              localStorage.setItem('cart',JSON.stringify(newState));

              return newState;

        default:
          return state;
    }
}



const reducer=combineReducers({bookReducer,cartReducer});
export default reducer;
